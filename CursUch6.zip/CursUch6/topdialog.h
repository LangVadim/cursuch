#ifndef TOPDIALOG_H
#define TOPDIALOG_H

#include <QDialog>
#include <QSqlTableModel>
#include <QTableView>
#include <QStandardItemModel>
#include <QSqlRecord>

namespace Ui {
class topDialog;
}

class topDialog : public QDialog
{
    Q_OBJECT

public:
    explicit topDialog(QWidget *parent = nullptr);
    ~topDialog();

private slots:
    void setupTopTable();

    void on_closeAcButton_clicked();

private:
    Ui::topDialog *ui;
    QSqlTableModel *topModel;
};

#endif // TOPDIALOG_H
