#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , database(new Database())
    , acountWin(nullptr)
{
    ui->setupUi(this);

    if (!database->openDatabase())
    {
        qDebug() << "Cannot open database:" << database->lastError();
        QMessageBox::critical(this, "Ошибка базы данных", "Не удалось открыть базу данных");
        return;
    }

    database->createUserTable();
    database->createDataUserTable();
    database->createLeadersTable();
    database->createAchievementsTable();

    database->populateTables();

    this->setFixedSize(this->size());
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_openAcButton_clicked()
{
    QString login = ui->inputLogin->text();
    QString password = ui->inputPassword->text();

    QSqlDatabase db = database->getDatabase();
    QSqlQuery query(db);

    query.prepare("SELECT * FROM User WHERE Login = :login AND Password = :password");
    query.bindValue(":login", login);
    query.bindValue(":password", password);

    if (query.exec() && query.next()) {
        qDebug() << "User authenticated successfully. Opening statistics window.";

        // Вывести информацию о найденных записях
        qDebug() << "User ID:" << query.value(0).toInt();
        qDebug() << "Login:" << query.value(1).toString();
        qDebug() << "Password:" << query.value(2).toString();
        qDebug() << "ID DataUser:" << query.value(3).toInt();

        // Открываем или обновляем окно статистики
        if (!acountWin) {
            acountWin = new acountWindow(database, this);
            acountWin->updateStatistics(login);
            acountWin->show();
        } else {
            // Если окно уже открыто, убедитесь, что оно видимо
            acountWin->setVisible(true);
            // Если окно уже открыто, обновим данные
            acountWin->updateStatistics(login);
        }
    } else {
        // Иначе выводим сообщение об ошибке
        QMessageBox::warning(this, "Ошибка входа", "Неверный логин или пароль");
    }
}
