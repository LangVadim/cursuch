#ifndef ACOUNTWINDOW_H
#define ACOUNTWINDOW_H

#include "database.h"
#include "topdialog.h"

#include <QMainWindow>
#include <QWidget>
#include <QLabel>
#include <QSqlQuery>

namespace Ui {
class acountWindow;
}

class acountWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit acountWindow(Database *db, QWidget *parent = nullptr);
    ~acountWindow();

    void updateStatistics(const QString &login);

private slots:
    void on_closeAcButton_clicked();

    void on_topButton_clicked();

private:
    Ui::acountWindow *ui;
    Database *database;
    QLabel *nameLabel;
    QLabel *levlLabel;
    QLabel *timeLabel;
    QLabel *registrLabel;
    topDialog* m_topDialog;
};

#endif // ACOUNTWINDOW_H
