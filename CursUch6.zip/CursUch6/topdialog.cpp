#include "topdialog.h"
#include "ui_topdialog.h"

topDialog::topDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::topDialog)
{
    ui->setupUi(this);
    setupTopTable();

    this->setFixedSize(this->size());
}

topDialog::~topDialog()
{
    delete ui;
}

void topDialog::setupTopTable()
{
    topModel = new QSqlTableModel(this);
    topModel->setTable("Leaders");
    topModel->setSort(3, Qt::DescendingOrder);  // Сортировка по убыванию уровня

    // Устанавливаем заголовки для столбцов
    topModel->setHeaderData(1, Qt::Horizontal, tr("Имя игрока"));
    topModel->setHeaderData(2, Qt::Horizontal, tr("Время"));
    topModel->setHeaderData(3, Qt::Horizontal, tr("Уровень"));

    topModel->select();  // Загружаем данные

    // Привязываем модель к таблице
    ui->topTableView->setModel(topModel);
    ui->topTableView->setEditTriggers(QAbstractItemView::NoEditTriggers);  // Запрещаем редактирование ячеек
    ui->topTableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);  // Растягиваем столбцы
    ui->topTableView->setColumnHidden(0, true);  // Скрыть столбец с индексом 0 (id пользователя)
}

void topDialog::on_closeAcButton_clicked()
{
    close();
}

