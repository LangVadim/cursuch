#ifndef DATABASE_H
#define DATABASE_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

class Database
{
public:
    Database();
    ~Database();

    bool openDatabase();
    void closeDatabase();

    bool createUserTable();
    bool createDataUserTable();
    bool createLeadersTable();
    bool createAchievementsTable();

    bool populateTables();

    // Метод для получения последней ошибки
    QString lastError() const;
    // Метод для получения базы данных
    QSqlDatabase getDatabase() const;

    // Метод для очистки базы данных
    void clearDatabase();

private:
    QSqlDatabase db; // Объект базы данных
    QString m_lastError; // Объект ошибки
};

#endif // DATABASE_H
