#include "acountwindow.h"
#include "ui_acountwindow.h"

acountWindow::acountWindow(Database *db, QWidget *parent) :
    QMainWindow(parent)
    , ui(new Ui::acountWindow)
    , database(db)
    , m_topDialog(nullptr)
{
    ui->setupUi(this);

    // Привязываем QLabel к объектам в ui
    nameLabel = ui->nameLabel;
    levlLabel = ui->levlLabel;
    timeLabel = ui->timeLabel;
    registrLabel = ui->registrLabel;

    // Подключите слот к нажатию кнопки
    connect(ui->topButton, &QPushButton::clicked, this, &acountWindow::on_topButton_clicked);
    this->setFixedSize(this->size());
}

acountWindow::~acountWindow()
{
    delete ui;
}

void acountWindow::updateStatistics(const QString &login)
{
    QSqlDatabase db = database->getDatabase();
    QSqlQuery query(db);

    query.prepare("SELECT * FROM DataUser WHERE Name = :name");
    query.bindValue(":name", login);

    if (query.exec() && query.next()) {
        // Обновляем значения QLabel
        nameLabel->setText(query.value(1).toString());
        levlLabel->setText(query.value(3).toString());
        timeLabel->setText(query.value(2).toString());
        registrLabel->setText(query.value(4).toString());
    } else {
        // В случае ошибки выводим предупреждение
        qDebug() << "Error retrieving user data:" << query.lastError().text();
        // Можно также очистить значения QLabel или установить их в значение по умолчанию
        nameLabel->clear();
        levlLabel->clear();
        timeLabel->clear();
        registrLabel->clear();
    }
}

void acountWindow::on_closeAcButton_clicked()
{
    close();
}

void acountWindow::on_topButton_clicked()
{
    // Если topDialog не создан или он был уничтожен, создайте его
    if (!m_topDialog || m_topDialog->isHidden())
    {
        m_topDialog = new topDialog(this);
        // Установите флаг, чтобы освободить память при закрытии
        m_topDialog->setAttribute(Qt::WA_DeleteOnClose, true);
        // Покажите диалоговое окно
        m_topDialog->show();
    } else {
        m_topDialog->setVisible(true);
    }
}


