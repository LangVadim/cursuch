#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "database.h"
#include "acountwindow.h"

#include <QMainWindow>
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QSqlQuery>
#include <QMessageBox>
#include <QDebug>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_openAcButton_clicked();

private:
    Ui::MainWindow *ui;
    Database *database;
    acountWindow *acountWin;
};
#endif // MAINWINDOW_H
