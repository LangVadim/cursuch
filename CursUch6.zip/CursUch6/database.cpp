#include "database.h"

Database::Database()
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("Curs.db");
    clearDatabase();
}

Database::~Database()
{
    closeDatabase();
}

bool Database::openDatabase()
{
    if (db.open())
    {
        m_lastError.clear();
        return true;
    }
    else
    {
        m_lastError = db.lastError().text();
        return false;
    }
}

void Database::closeDatabase()
{
    db.close();
}

void Database::clearDatabase()
{
    if (openDatabase())
    {
        QSqlQuery query(db);
        query.exec("DROP TABLE IF EXISTS Achievements");
        query.exec("DROP TABLE IF EXISTS Leaders");
        query.exec("DROP TABLE IF EXISTS User");
        query.exec("DROP TABLE IF EXISTS DataUser");
        closeDatabase();
    }
}

bool Database::createAchievementsTable()
{
    QSqlQuery query(db);
    return query.exec("CREATE TABLE IF NOT EXISTS Achievements ("
                      "idAchievements INTEGER PRIMARY KEY,"
                      "TimeAchievement TEXT,"
                      "LevelAchievements INTEGER"
                      ")");
}

bool Database::createDataUserTable()
{
    QSqlQuery query(db);
    return query.exec("CREATE TABLE IF NOT EXISTS DataUser ("
                      "idDataUser INTEGER PRIMARY KEY,"
                      "Name TEXT,"
                      "Time TEXT,"
                      "Level INTEGER,"
                      "DataRegistration TEXT,"
                      "idAchievements INTEGER,"
                      "idTime INTEGER,"
                      "FOREIGN KEY (idAchievements) REFERENCES Achievements(idAchievements),"
                      "FOREIGN KEY (idTime) REFERENCES Time(idTime)"
                      ")");
}

bool Database::createUserTable()
{
    QSqlQuery query(db);
    return query.exec("CREATE TABLE IF NOT EXISTS User ("
                      "idUser INTEGER PRIMARY KEY,"
                      "Login TEXT,"
                      "Password TEXT,"
                      "idDataUser INTEGER,"
                      "FOREIGN KEY (idDataUser) REFERENCES DataUser(idDataUser)"
                      ")");
}

bool Database::createLeadersTable()
{
    QSqlQuery query(db);
    return query.exec("CREATE TABLE IF NOT EXISTS Leaders ("
                      "idLeaders INTEGER PRIMARY KEY,"
                      "Name TEXT,"
                      "TimeLeader TEXT,"
                      "LevelLeader INTEGER,"
                      "FOREIGN KEY (TimeLeader) REFERENCES DataUser(Time),"
                      "FOREIGN KEY (LevelLeader) REFERENCES DataUser(Level)"
                      ")");
}

bool Database::populateTables()
{
    QSqlQuery query(db);

    query.exec("INSERT INTO User (idUser, Login, Password, idDataUser) VALUES (1, 'user1', 'pass1', 1)");
    query.exec("INSERT INTO User (idUser, Login, Password, idDataUser) VALUES (2, 'user2', 'pass2', 2)");
    query.exec("INSERT INTO User (idUser, Login, Password, idDataUser) VALUES (3, 'user3', 'pass3', 3)");
    query.exec("INSERT INTO User (idUser, Login, Password, idDataUser) VALUES (4, 'user4', 'pass4', 4)");

    query.exec("INSERT INTO DataUser (idDataUser, Name, Time, Level, DataRegistration, idAchievements) VALUES (1, 'user1', '10', 5, '2023-01-01', 1)");
    query.exec("INSERT INTO DataUser (idDataUser, Name, Time, Level, DataRegistration, idAchievements) VALUES (2, 'user2', '12', 7, '2023-01-02', 2)");
    query.exec("INSERT INTO DataUser (idDataUser, Name, Time, Level, DataRegistration, idAchievements) VALUES (3, 'user3', '9', 10, '2023-02-04', 3)");
    query.exec("INSERT INTO DataUser (idDataUser, Name, Time, Level, DataRegistration, idAchievements) VALUES (4, 'user4', '6', 9, '2023-04-04', 4)");

    query.exec("INSERT INTO Leaders (idLeaders, Name, TimeLeader, LevelLeader) VALUES (1, 'user1', '10', 5)");
    query.exec("INSERT INTO Leaders (idLeaders, Name, TimeLeader, LevelLeader) VALUES (2, 'user2', '12', 7)");
    query.exec("INSERT INTO Leaders (idLeaders, Name, TimeLeader, LevelLeader) VALUES (3, 'user3', '9', 10)");
    query.exec("INSERT INTO Leaders (idLeaders, Name, TimeLeader, LevelLeader) VALUES (4, 'user4', '6', 9)");

    query.exec("INSERT INTO Achievements (TimeAchievement, LevelAchievements) VALUES (1, '10:30', 5)");
    query.exec("INSERT INTO Achievements (TimeAchievement, LevelAchievements) VALUES (2, '12:45', 7)");
    query.exec("INSERT INTO Achievements (TimeAchievement, LevelAchievements) VALUES (3, '9:30', 10)");
    query.exec("INSERT INTO Achievements (TimeAchievement, LevelAchievements) VALUES (4, '6:15', 9)");

    return true;
}

QString Database::lastError() const
{
    return m_lastError;
}

QSqlDatabase Database::getDatabase() const
{
    return db;
}
