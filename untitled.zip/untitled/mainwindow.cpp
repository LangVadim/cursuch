#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(":memory:");

    if (!db.open()) {
        qDebug() << "Ошибка открытия базы данных:" << db.lastError().text();
        return;
    }

    QSqlQuery query;
    if (!query.exec("CREATE TABLE users (login TEXT, password TEXT)")) {
        qDebug() << "Ошибка создания таблицы users:" << query.lastError().text();
        return;
    }

    if (!query.exec("INSERT INTO users VALUES ('11', 'qwerty'), ('22', 'admin')")) {
        qDebug() << "Ошибка заполнения таблицы users:" << query.lastError().text();
        return;
    }

    if (!query.exec("CREATE TABLE hours (login TEXT, hours INTEGER)")) {
        qDebug() << "Ошибка создания таблицы hours:" << query.lastError().text();
        return;
    }

    if (!query.exec("INSERT INTO hours VALUES ('11', 10), ('22', 20)")) {
        qDebug() << "Ошибка заполнения таблицы hours:" << query.lastError().text();
        return;
    }

    bool ok;
    QString login = QInputDialog::getText(0, "Вход", "Логин:", QLineEdit::Normal, "", &ok);
    if (ok && !login.isEmpty()) {
        QString password = QInputDialog::getText(0, "Вход", "Пароль:", QLineEdit::Password, "", &ok);
        if (ok && !password.isEmpty()) {
            if (!query.exec(QString("SELECT hours FROM hours WHERE login IN (SELECT login FROM users WHERE login='%1' AND password='%2')").arg(login, password))) {
                qDebug() << "Ошибка запроса к таблице hours:" << query.lastError().text();
                return;
            }

            if (query.next()) {
                QMessageBox::information(this, "Сыгранные часы", "Количество сыгранных часов: " + QString::number(query.value(0).toInt()));
            } else {
                QMessageBox::warning(this, "Ошибка", "Неверный логин или пароль");
            }
        }
    }
}

MainWindow::~MainWindow()
{
    db.close();
}
